package com.descolab.chbpip.service.response


data class Berita(
    val id: String,
    val title: String,
    val description: String,
    val img: String,
)