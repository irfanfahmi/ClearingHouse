package com.descolab.chbpip.mitra_mou

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.descolab.chbpip.R

class DetailMouActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_mou)

    }
}